const JWT_KEY = 'sockets_admin_2023';

module.exports = { JWT_KEY };