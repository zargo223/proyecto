const users = [
  { username: 'admin', password: 'admin' },
  { username: 'test', password: 'test' }
];

module.exports = { users };
